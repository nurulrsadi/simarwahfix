<ul class="icons" class="text-left">
	<li><a href=#awal> Panduan Awal</a></li>
	<li><a href=#dana> Pengajuan Dana</a></li>
	<li><a href=#aula> Peminjaman Aula</a></li>
</ul>
</header>
<section id="awal">
	<article>
		<div class="main">
			<header>
				<h2>Panduan Awal Pengguna Baru SIMARWAH</h2>
			</header>
			<!-- <h3 id="content">Apa itu SIMWARAH ?</h3>
                <p>Praesent ac adipiscing ullamcorper semper ut amet ac risus. Lorem sapien ut odio odio nunc. Ac adipiscing nibh porttitor erat risus justo adipiscing adipiscing amet placerat accumsan. Vis. Faucibus odio magna tempus adipiscing a non. In mi primis arcu ut non accumsan vivamus ac blandit adipiscing adipiscing arcu metus praesent turpis eu ac lacinia nunc ac commodo gravida adipiscing eget accumsan ac nunc adipiscing adipiscing lorem ipsum dolor sit amet nullam veroeros adipiscing.</p>  -->
		</div>
	</article>
	<div class="features">

		<article>
			<!-- <span class="icon fa-gem"></span> -->
			<div class="content">
				<img src="<?php echo base_url('assets/img/tutorial/412.png')?>" class="img-fluid" alt="Responsive image"
					width="100%">
			</div>
		</article>
		<article>
			<div class="content">
				<h4>Apa itu SIMARWAH? </h4>
				<blockquote>Lorem ipsum dolor vestibulum ante ipsum primis in faucibus vestibulum. Blandit adipiscing eu felis
					iaculis volutpat ac adipiscing accumsan eu faucibus. Integer ac pellentesque praesent. Lorem ipsum dolor.
					Lorem ipsum dolor vestibulum ante ipsum primis in faucibus vestibulum. Blandit adipiscing eu felis iaculis
					volutpat ac adipiscing accumsan eu faucibus.</blockquote>
			</div>
		</article>
	</div>
</section>

<section id="dana">
	<header class="main">
		<h2>Pengajuan Uang</h2>
	</header>

	<span class="image main"><img src="<?php echo base_url('assets/img/tutorial/2.png')?>" alt="" /></span>

	<h4>Ingat !</h4>
	<ol>
		<li>Dolor etiam magna etiam.</li>
		<li>Etiam vel lorem sed viverra.</li>
		<li>Felis dolore viverra.</li>
		<li>Dolor etiam magna etiam.</li>
		<li>Etiam vel lorem sed viverra.</li>
		<li>Felis dolore viverra.</li>
	</ol>

</section>
<section id="aula">
	<header class="main">
		<h2 id="#aula">Peminjaman Aula SC</h2>
	</header>

	<span class="image main"><img src="<?php echo base_url('assets/img/tutorial/3.png')?>" alt="" /></span>

	<h4>Ingat !</h4>
	<ol>
		<li>Dolor etiam magna etiam.</li>
		<li>Etiam vel lorem sed viverra.</li>
		<li>Felis dolore viverra.</li>
		<li>Dolor etiam magna etiam.</li>
		<li>Etiam vel lorem sed viverra.</li>
		<li>Felis dolore viverra.</li>
	</ol>

</section>
</div>
</div>
