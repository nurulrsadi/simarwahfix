</header>

<!-- modal for information at header -->

<!-- Content -->
<section>
	<header class="main">

	</header>

	<div class="features">

		<article>
			<!-- <span class="icon fa-gem"></span> -->
			<div class="content">
				<img src="<?php echo base_url('assets/img/cekfile.png')?>" class="img-fluid" alt="Responsive image"
					width="100%">
			</div>
		</article>
		<article>
			<div class="content">
				<p class="customtextcheckdana">Laporan kegiatan anda sedang kami cek,
					<br>silahkan
					tunggu verifikasi agar dapat melakukan pengajuan dana selanjutnya.</p>

			</div>
		</article>
	</div>
</section>
</div>
</div>
